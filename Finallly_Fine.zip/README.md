# Doctrina Aeterna
Repo for CS771 mini project 2 in Odd Semester 2024-25